extends Control

@onready var main_menu = $MainMenu
@onready var game = $Game
@onready var settings = $Settings
@onready var contacts = $Contacts
@onready var confirm_overlay = $Game/ConfirmOverlay
@onready var start: AudioStreamPlayer2D = $MainMenu/PlayButton/Start


func _on_play_button_pressed():
	main_menu.visible = false
	game.visible = true
	start.play()

func _on_exit_button_pressed():
	start.play()
	get_tree().quit()

func _on_settings_button_pressed():
	start.play()
	main_menu.visible = false
	settings.visible = true

func _on_back_button_pressed():
	start.play()
	settings.visible = false
	main_menu.visible = true

func _on_volume_slider_value_changed(value):
	start.play()
	AudioServer.set_bus_volume_db(0, linear_to_db(value))

func _on_fullscreen_check_toggled(toggled_on):
	start.play()
	if toggled_on:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)

func _on_game_menu_button_pressed():
	start.play()
	confirm_overlay.visible = true

func _on_confirm_exit_button_pressed():
	start.play()
	confirm_overlay.visible = false
	game.visible = false
	main_menu.visible = true

func _on_stay_button_pressed():
	start.play()
	confirm_overlay.visible = false

func _on_contact_button_pressed():
	start.play()
	main_menu.visible = false
	contacts.visible = true

func _on_contacts_back_button_pressed():
	start.play()
	contacts.visible = false
	main_menu.visible = true
